(function($) {
	$(document).ready( function($) {
		$('body').append('<div class="tempdiv">');
		$('.tempdiv').hide();
		$('.pagination').hide();

		var maxpages;
		var nextpage;

		function pager () {
			if(maxpages >= nextpage)return;
			var pagelist = $(".pagination span").html().split(" of ");
			maxpages = parseInt(pagelist[1]);
			nextpage = $(".older-posts").attr("href").split("/");
			nextpage = parseInt(nextpage[2]);
			$("#primary > .inner").append('<div class="load-more"><span class="more active">Load More Posts<i class="icon-angle-right"></i></span></div>');
		}

		function loadedElements () {
			$(".more").delegate(this, "click", function () {
				if(maxpages <= nextpage-1)return;

				$(".more").html("Loading...");
				$(".tempdiv").load('/page/'+nextpage+'/ #primary > .inner', function (data) {
					var tempdata = $(this).children(".inner").html();
					$("#primary .inner .load-more").before(tempdata);
					nextpage+=1;
					$('.pagination').hide();
					if(maxpages <= nextpage-1){
						$(".more").removeClass('active').html("No More Posts");
					}else{
						$(".more").addClass('active').html('Load More Posts <i class="icon-angle-right"></i>');
					}
				});
			});
		}

		pager();
		loadedElements();

	});

})(jQuery);