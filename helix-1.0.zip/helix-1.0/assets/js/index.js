/**
 * Main JS file
 */

(function ($) {

	$(document).ready(function(){

		$('body').delay( 1000 ).removeClass('not-loaded');

		$(".entry-content").fitVids();

		winHeight = $(window).height();
		$('.home.cover-image').css({ 'height' : winHeight });

		headerHeight = $('#header').height();
		coverHeight = $('.cover-image').height()
		headerTop = (coverHeight * 0.5) - (headerHeight * 0.5 );
		$('#header').css({ 'top' : headerTop});

		$('#to-content').on('click', function(){
			$('html,body').animate({scrollTop: $('#primary').offset().top}, 800);
		});

	});

}(jQuery));
