(function($) {
	$(document).ready(function() {
		new WOW().init();

		//Rotator
		$('.bxslider').bxSlider({
			auto: false,
			mode: 'fade',
			adaptiveHeight: true,
			nextText: '',
			prevText: '',
		});


		//Account for Archive Loop posts with no images
		$('.entry.excerpt').each(function() {
			if( $('.entry-image img', this).length < 1 ) {
				$('.entry-image', this).hide();
				$('.entry-header', this).css({
					'float': 'none',
					'width' : '100%',
					'padding-right' : 0
				});
			}
		});

		$('body').append('<div class="tempdiv">');
		$('.tempdiv').hide();
		$('.pagination').hide();

		var maxpages;
		var nextpage;

		function pager () {
			if(maxpages >= nextpage)return;
			var pagelist = $(".pagination span").html().split(" of ");
			maxpages = parseInt(pagelist[1]);
			nextpage = $(".older-posts").attr("href").split("/");
			nextpage = parseInt(nextpage[2]);
			$("#primary > .inner").append('<div class="load-more"><span class="more active">Load More Posts...</span></div>');
		}

		function loadedElements () {
			$(".more").delegate(this, "click", function () {
				if(maxpages <= nextpage-1)return;

				$(".more").html("Loading...");
				$(".tempdiv").load('/page/'+nextpage+'/ #primary > .inner', function (data) {
					var tempdata = $(this).children(".inner").html();
					$("#primary .inner .load-more").before(tempdata);
					nextpage+=1;
					$('.pagination').hide();
					if(maxpages <= nextpage-1){
						$(".more").removeClass('active').html("No More Posts");
					}else{
						$(".more").addClass('active').html("Load More Posts...");
					}
				});
			});
		}

		pager();
		loadedElements();

	});
})(jQuery);