/**
 * Main JS file
 */

(function ($) {
    "use strict";

    $(document).ready(function(){

        $(".entry-content").fitVids();

    });

}(jQuery));
